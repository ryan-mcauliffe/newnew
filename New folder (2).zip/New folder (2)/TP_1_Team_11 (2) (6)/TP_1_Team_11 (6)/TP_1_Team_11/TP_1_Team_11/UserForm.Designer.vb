﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class UserForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Friend WithEvents ProjectDatabaseDataSetBindingSource As BindingSource
    Friend WithEvents ProjectDatabaseDataSet As ProjectDatabaseDataSet
    Friend WithEvents CarsTableBindingSource As BindingSource
    Friend WithEvents CarsTableAdapter As ProjectDatabaseDataSetTableAdapters.CarsTableAdapter
    Friend WithEvents CarsNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CarsBindingSource As BindingSource
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CarNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CostDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MPGDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ComfortDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents UtilityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents InteriorDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CarsBindingSource1 As BindingSource
End Class

