﻿Imports Microsoft.SolverFoundation.Common
Imports Microsoft.SolverFoundation.Services
Imports Microsoft.SolverFoundation.Solvers
'****************************************************************************************************************
Public Class Optimization
    Public TP_1 As New SimplexSolver 'RPM: declares the following object in this class
    Dim dvKey As String
    Dim dvIndex As Integer
    Dim coefficient As Single
    Dim constraintKey As String
    Dim constraintIndex As Integer
    ReadOnly objKey As String = "Objective Function"
    Dim objIndex As Integer
    Public optimalObj As Single
    Public dvValues(Cars.CarsList.Count - 1, Customers.CustomerList.Count - 1) As Single

    Public Shared ReadOnly NegativeInfinity As Rational
    Public Shared ReadOnly PositiveInfinity As Rational
    '************************************************************************************
    'RPM: creates the components of the decision model
    Public Sub RPMBuildModel()
        '----------------------------------------------------------------------------------------------------------
        'RPM: defines the decision variables for shifts
        For Each myCar As Cars In Cars.CarsList
            dvKey = "Car Choice " & myCar.CarName
            TP_1.AddVariable(dvKey, dvIndex)
            TP_1.SetBounds(dvIndex, 0, 1)
            TP_1.SetIntegrality(dvIndex, True)
        Next
        For Each myGoal As Customers In Customers.CustomerList
            dvKey = "Dplus " & myGoal.SatisfactionMeasure
            TP_1.AddVariable(dvKey, dvIndex)
            TP_1.SetBounds(dvIndex, 0, Rational.PositiveInfinity)
            dvKey = "Dminus " & myGoal.SatisfactionMeasure
            TP_1.AddVariable(dvKey, dvIndex)
            TP_1.SetBounds(dvIndex, 0, Rational.PositiveInfinity)

        Next
        '----------------------------------------------------------------------------------------------------------
        'RPM: create capacity constraints for employees
        For Each myCar As Cars In Cars.CarsList
            constraintKey = myCar.CarName & "Capacity Constraint"
            TP_1.AddRow(constraintKey, constraintIndex)
            TP_1.SetBounds(constraintIndex, 0, 1)
            For Each myCust As Customers In Customers.CustomerList
                dvKey = myCar.CarName & "_" & myCust.SatisfactionMeasure
                coefficient = 1
                TP_1.GetIndexFromKey(dvKey)
                TP_1.SetCoefficient(constraintIndex, dvIndex, coefficient)
            Next
            TP_1.SetBounds(constraintIndex, 0, 1)
        Next
        ' ----------------------------------------------------------------------------------------------------------
        For Each myCust As Customers In Customers.CustomerList
            constraintKey = "Requirement Constrant" & "+" & myCust.Goal
            TP_1.AddRow(constraintKey, constraintIndex)
            'RPM: requirement constraints for employees
            For Each myCar As Cars In Cars.CarsList
                dvIndex = TP_1.GetIndexFromKey(dvKey)
                coefficient = 1
                TP_1.SetCoefficient(constraintIndex, dvIndex, coefficient)
            Next
            'RPM: sets bounds
            TP_1.SetBounds(constraintIndex, 0, myCust.Budget)
        Next
        '*************************************************************************************************************
        ' RPM: defines the objective function
        TP_1.AddRow(objKey, objIndex)
    End Sub
    Public Sub ShowAnswer()
        '----------------------------------------------------------------------------------------------------------
        'RDB: Now we display the optimal values of the variables and objective function
        optimalObj = CSng(TP_1.GetValue(objIndex).ToDouble)

        'RDB: We transfer the values of the decision variables to an array 
        Dim rowIndex As Integer = 0
        Dim columnIndex As Integer = 0

        '
        For Each cars As Cars In Cars.CarsList
            rowIndex = Cars.CarsList.IndexOf(cars)
            For Each cust As Customers In Customers.CustomerList
                columnIndex = Customers.CustomerList.IndexOf(cust)
                dvKey = cars.CarName & "_" & cust.Goal
                dvIndex = TP_1.GetIndexFromKey(dvKey)
                dvValues(rowIndex, columnIndex) = CSng(TP_1.GetValue(dvIndex).ToDouble)
            Next
        Next
        '************************************************************************************
        Solution.TableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        '
        'RDB: We enter the column headings into the table
        For column As Integer = 1 To Solution.TableLayoutPanel1.ColumnCount - 1
            Dim myLabel As New Label
            myLabel.Text = "Activity " & CStr(column)
            Solution.TableLayoutPanel1.Controls.Add(myLabel)
            myLabel.Visible = True
            myLabel.TextAlign = ContentAlignment.MiddleCenter
            Solution.TableLayoutPanel1.SetRow(myLabel, 0)
            Solution.TableLayoutPanel1.SetColumn(myLabel, column)
            myLabel.Anchor = AnchorStyles.Bottom
            myLabel.Anchor = AnchorStyles.Top
            myLabel.Anchor = AnchorStyles.Left
            myLabel.Anchor = AnchorStyles.Right

        Next
        '
        'RDB: We enter the row headings into the table
        rowIndex = 0
        For Each dept As Cars In Cars.CarsList
            Dim myLabel As New Label
            myLabel.Text = dept.CarName
            myLabel.Visible = True
            myLabel.TextAlign = ContentAlignment.MiddleCenter
            Solution.TableLayoutPanel1.SetRow(myLabel, rowIndex + 1)
            Solution.TableLayoutPanel1.SetColumn(myLabel, 0)
            Solution.TableLayoutPanel1.Dock = DockStyle.Fill
            Solution.TableLayoutPanel1.Controls.Add(myLabel)
            myLabel.Anchor = AnchorStyles.Bottom
            myLabel.Anchor = AnchorStyles.Top
            myLabel.Anchor = AnchorStyles.Left
            myLabel.Anchor = AnchorStyles.Right
            rowIndex += 1
        Next

        For row As Integer = 1 To Solution.TableLayoutPanel1.RowCount - 1
            For column As Integer = 1 To Solution.TableLayoutPanel1.ColumnCount - 1
                Dim myLabel As New Label
                myLabel.Text = CStr(dvValues(row - 1, column - 1))
                myLabel.Visible = True
                myLabel.TextAlign = ContentAlignment.MiddleCenter
                Solution.TableLayoutPanel1.SetRow(myLabel, row)
                Solution.TableLayoutPanel1.SetColumn(myLabel, column)
                Solution.TableLayoutPanel1.Dock = DockStyle.Fill
                Solution.TableLayoutPanel1.Controls.Add(myLabel)
                myLabel.Anchor = AnchorStyles.Bottom
                myLabel.Anchor = AnchorStyles.Top
                myLabel.Anchor = AnchorStyles.Left
                myLabel.Anchor = AnchorStyles.Right
            Next
        Next
        Solution.Show()

    End Sub
End Class
